angular.module('root.js', [])
	.controller("index", ["$scope", function ($scope) {
		$scope.message = "Hello Dunia";
	}]);